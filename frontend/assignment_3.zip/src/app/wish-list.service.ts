import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class WishlistService {
  wishlist:any = [];

  constructor(private http: HttpClient) {}

  async fetchWishlist() {
    let response$ = this.http.get('http://localhost:8080/wishlist-fetech');
    this.wishlist = await lastValueFrom(response$);
    console.log(this.wishlist);
  }

  async addToWishlist(product: any) {
    this.wishlist.push(product);
    let response$ = this.http.post('http://localhost:8080/wishlist-operate', {'product': product, 'action': "add"});
    let result = await lastValueFrom(response$);
    console.log(result, this.wishlist)
  }

  async removeFromWishlist(product: any) {
    this.wishlist = this.wishlist.filter((item: any) => item.itemId != product.itemId);
    let response$ = this.http.post('http://localhost:8080/wishlist-operate', {'product': product, 'action': "remove"});
    let result = await lastValueFrom(response$);
    console.log(result, this.wishlist)
  }

  isOnWishlist(product: any): boolean {
    return this.wishlist.find((item: any) => item.itemId == product.itemId) !== undefined;
  }

  toggleWishlist(product: any) {
    if (this.isOnWishlist(product)){
      this.removeFromWishlist(product);
    } else {
      this.addToWishlist(product);
    }
  }
}